# gem-dmm-agent-pack — Agent Configuration Pack (Gemini Gem)
Version: 1.0.0  
Created: 2026-02-13  
Agent: **Super Acting Digital Marketing Expert**

## What this pack is
This is a production-grade, platform-agnostic configuration pack designed to be imported into a **Gemini Gem** and used as a **discovery-first, evidence-grounded (2026)** digital marketing strategist.

Core behavior:
1) Runs a structured discovery interview (≤5 questions per round)
2) Forces **ONE Core Question (CQ)** and refuses to proceed until CQ is valid
3) Performs external grounding (official docs first) and enforces evidence rules
4) Produces a full digital marketing strategy + execution plan + measurement spec
5) Runs QA/red-team checks before final handoff
6) Localizes strategies for **Egypt + GCC** markets with language/culture/seasonality awareness

## Directory overview
- `config/` — rules, guardrails, sources, scoring, and output contract
- `prompts/` — system prompt + flows + research/strategy/execution/QA prompt kits
- `schemas/` — JSON schemas for intake, brief, CQ, strategy, measurement, experiments, memory entries
- `templates/` — copy/paste templates for discovery, strategy, channels, experiments, tracking, weekly review
- `examples/` — sample brief and sample output format

## How to use in Gemini Gems (recommended workflow)
1) Create a new Gemini Gem.
2) Paste the contents of `prompts/system_prompt.txt` into the Gem’s “Instructions” field.
3) Upload this entire folder (or at minimum `config/`, `prompts/`, `templates/`, `examples/`) into the Gem’s knowledge area if supported.
4) Start a session by describing your business goal in plain language.

The agent will automatically start at:
- Stage 0 (safety/scope) → Stage 1 (discovery) → Stage 2 (CQ lock)

It will refuse to generate a strategy until:
- discovery is complete, AND
- CQ is valid, AND
- grounding plan is created (and executed if browsing is enabled).

## How the discovery flow works
Use `prompts/discovery_flow.md` as the interview script.
Rules:
- The agent asks **≤5 questions** per round.
- After each round the agent summarizes knowns/unknowns and drafts a CQ.
- If the CQ is invalid, the agent asks only the missing questions.

## Evidence & grounding rules (2026)
Configured in:
- `config/grounding_sources.yaml`
- `config/scoring_models.yaml`

Hard rules:
- Key recommendations require **≥3 independent confirmations**.
- Apply **recency decay after 120 days** for time-sensitive claims.
- Include **dates** for time-sensitive claims.
- Reddit is qualitative context only and never counts as a confirmation.

## Egypt + GCC localization notes
The pack is tuned for Egypt, Saudi Arabia, UAE, and GCC markets:
- Dialect-aware content guidance (Egyptian/Gulf Arabic when requested)
- Seasonal demand planning (Ramadan/Eid, Hajj/Umrah, local holidays)
- Regional channel preferences (validate with current data)

## Safety & privacy guidance
Do not paste:
- passwords, API keys, OAuth tokens
- full customer lists (emails, phones)
- payment details

Prefer:
- ranges and aggregates (e.g., “CVR 1.2–2.1%”)
- anonymized examples with sensitive details removed

## Quickstart prompts (copy/paste)

### 1) B2B SaaS
“We’re a B2B SaaS. Our main goal is qualified demos. Please start the discovery interview. Don’t give strategy until you lock the Core Question.”

### 2) Ecommerce
“We’re ecommerce. Goal is profitable repeat purchases. Start discovery and lock a CQ before recommending channels.”

### 3) Local services
“We’re a local services business. Goal is qualified leads. Start discovery and create a measurement spec (GA4/GTM) once CQ is valid.”

## Notes on citations
This pack allows placeholders in the “Evidence Citations Plan” while browsing is pending. If browsing is enabled, the agent should replace placeholders with direct URLs and accessed/publish dates.
